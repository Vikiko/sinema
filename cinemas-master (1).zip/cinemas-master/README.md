# cinemas
Test console project. Run admin.py, setup this, and run client.py :)
