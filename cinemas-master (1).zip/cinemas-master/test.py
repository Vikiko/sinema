print("ADD_FILM halls='haLL' title='soyka_peresmeshntsa' actual='30'".split('=\''))
